# OPENSSL TOOL STUDY DOCUMENT
### Academic Reference Guide — OpenSSL Cryptographic Toolkit
---

## TABLE OF CONTENTS

1. [Introduction](#1-introduction)
2. [What is OpenSSL](#2-what-is-openssl)
3. [Features of OpenSSL](#3-features-of-openssl)
4. [Why OpenSSL is Important](#4-why-openssl-is-important)
5. [Relation to AES-256 Encryption](#5-relation-to-aes-256-encryption)
6. [Practical Commands](#6-practical-commands)
7. [Expected Outputs](#7-expected-outputs)
8. [Conclusion](#8-conclusion)

---

## 1. Introduction

In the modern digital era, the security of sensitive data during storage and transmission is a critical requirement for any software system. Cryptographic tools play a central role in ensuring confidentiality, integrity, and authenticity of data. Among the most widely used and trusted cryptographic libraries in the world is **OpenSSL**.

This document serves as an academic study guide focused on OpenSSL — its architecture, purpose, features, and practical use. Special attention is given to its role in implementing **AES-256 encryption**, which is considered one of the strongest symmetric encryption algorithms currently available and is widely adopted in enterprise-grade and academic applications alike.

This study is intended for students, researchers, and developers who wish to understand OpenSSL both conceptually and practically, including how to use it to secure data with industry-standard encryption techniques.

---

## 2. What is OpenSSL

### Definition

**OpenSSL** is a robust, open-source, full-featured cryptographic library and toolkit that implements the **Secure Sockets Layer (SSL)** and **Transport Layer Security (TLS)** protocols. It also provides a wide range of cryptographic functions for use in general-purpose applications.

### Origin and History

| Year | Milestone |
|------|-----------|
| 1995 | SSLeay library created by Eric A. Young and Tim Hudson |
| 1998 | OpenSSL project forked from SSLeay, open-sourced |
| 2002 | OpenSSL 0.9.7 released with improved algorithm support |
| 2010 | FIPS 140-2 validated module released |
| 2014 | Heartbleed vulnerability (CVE-2014-0160) discovered and patched |
| 2016 | OpenSSL 1.1.0 released with improved API |
| 2022 | OpenSSL 3.0 released with new provider architecture |
| 2023 | OpenSSL 3.1 / 3.2 released with enhanced performance |

### Core Components

OpenSSL is composed of three main layers:

1. **libssl** — Implements SSL/TLS protocol communication
2. **libcrypto** — Core cryptographic functions (ciphers, hashing, key generation, etc.)
3. **openssl CLI** — Command-line interface for using the library's features directly

### Supported Platforms

OpenSSL is cross-platform and runs on:
- Linux / Unix
- Windows
- macOS
- Embedded and IoT systems

### License

OpenSSL is released under the **Apache License 2.0** (since OpenSSL 3.x), making it freely usable in both open-source and commercial applications.

---

## 3. Features of OpenSSL

OpenSSL is a comprehensive toolkit offering an extensive set of cryptographic features. Below is a categorized overview:

---

### 3.1 Symmetric Encryption

Symmetric encryption uses the same key for both encryption and decryption. OpenSSL supports:

| Algorithm | Key Sizes | Modes Supported |
|-----------|-----------|-----------------|
| AES | 128, 192, 256 bits | CBC, CFB, OFB, CTR, GCM, ECB |
| DES | 56 bits | CBC, ECB |
| 3DES (Triple DES) | 112, 168 bits | CBC, ECB |
| Blowfish | 32–448 bits | CBC |
| Camellia | 128, 192, 256 bits | CBC, CFB |
| ChaCha20 | 256 bits | — |

---

### 3.2 Asymmetric Encryption

Asymmetric encryption uses a public/private key pair. OpenSSL supports:

- **RSA** — Widely used for key exchange and digital signatures (1024–8192 bits)
- **DSA** — Digital Signature Algorithm for signing data
- **ECDSA** — Elliptic Curve Digital Signature Algorithm (more efficient than RSA)
- **DH / ECDH** — Diffie-Hellman key exchange (classical and elliptic curve variants)
- **Ed25519 / Ed448** — Modern elliptic curve signature schemes

---

### 3.3 Hash Functions (Message Digests)

Hash functions generate a fixed-size fingerprint of data. OpenSSL supports:

| Hash Function | Output Size | Status |
|---------------|-------------|--------|
| MD5 | 128 bits | Deprecated (insecure) |
| SHA-1 | 160 bits | Deprecated (weak) |
| SHA-256 | 256 bits | Secure ✓ |
| SHA-384 | 384 bits | Secure ✓ |
| SHA-512 | 512 bits | Secure ✓ |
| SHA3-256 | 256 bits | Secure ✓ |
| BLAKE2 | Variable | Secure ✓ |

---

### 3.4 SSL/TLS Protocol Support

OpenSSL implements both SSL and TLS protocols used to secure network communication:

- TLS 1.0, 1.1 (deprecated)
- **TLS 1.2** (widely used, still secure)
- **TLS 1.3** (latest, most secure and performant)
- DTLS (Datagram TLS for UDP-based communication)

---

### 3.5 Certificate Management (PKI)

OpenSSL includes full Public Key Infrastructure (PKI) support:

- **X.509 Certificate** generation and parsing
- **Certificate Signing Request (CSR)** creation
- **Self-signed certificate** generation
- **Certificate Authority (CA)** management
- **CRL (Certificate Revocation List)** support
- **OCSP (Online Certificate Status Protocol)** support

---

### 3.6 Key Derivation Functions (KDF)

OpenSSL supports several key derivation standards:

- **PBKDF2** — Password-Based Key Derivation Function 2
- **HKDF** — HMAC-based Extract-and-Expand Key Derivation Function
- **scrypt** — Memory-hard KDF resistant to brute-force

---

### 3.7 Message Authentication Codes (MAC)

OpenSSL provides:

- **HMAC** — Hash-Based Message Authentication Code
- **CMAC** — Cipher-Based Message Authentication Code
- **GMAC** — Galois Message Authentication Code (used with AES-GCM)

---

### 3.8 Random Number Generation

OpenSSL includes a **Cryptographically Secure Pseudo-Random Number Generator (CSPRNG)** based on:

- OS entropy sources (`/dev/urandom` on Linux, `CryptGenRandom` on Windows)
- Hardware random number generators (RDRAND instruction support)

---

### 3.9 Encoding and Format Support

- **Base64** encoding/decoding
- **PEM** (Privacy Enhanced Mail) and **DER** (Distinguished Encoding Rules) formats
- **PKCS#1, PKCS#8, PKCS#12** key/certificate container formats

---

## 4. Why OpenSSL is Important

### 4.1 Ubiquity and Adoption

OpenSSL is estimated to be used by **over two-thirds of all HTTPS-enabled servers** on the internet. It is the cryptographic backbone of:

- Apache and Nginx web servers
- OpenSSH (secure remote login)
- VPN software (OpenVPN, StrongSwan)
- Email servers (Postfix, Dovecot)
- Databases (MySQL, PostgreSQL — SSL connections)
- Cloud platforms and container orchestration systems

### 4.2 Security and Standards Compliance

OpenSSL implements internationally recognized standards:

- **FIPS 140-2 / 140-3** — US federal cryptographic standard for government use
- **NIST approved algorithms** — AES, SHA-2/3, RSA, ECDSA
- **RFC standards** — TLS (RFC 8446), X.509 (RFC 5280), etc.

### 4.3 Open-Source Trustworthiness

Because OpenSSL is open-source:

- Its code is publicly auditable by security researchers worldwide
- Vulnerabilities are discovered and patched by a global community
- It undergoes continuous peer review and third-party security audits

### 4.4 Education and Research Value

OpenSSL is the standard tool used in:

- Academic courses on cryptography and network security
- Penetration testing and ethical hacking labs
- Research into new cryptographic protocols and algorithms

### 4.5 Developer Integration

OpenSSL's **C library (libcrypto / libssl)** can be integrated into applications written in:

- C / C++
- Python (via `pyOpenSSL`, `cryptography` library)
- Java (via JNI bindings)
- Go, Rust, PHP, Ruby, and many more

---

## 5. Relation to AES-256 Encryption

### 5.1 What is AES-256?

**AES (Advanced Encryption Standard)** is a symmetric block cipher standardized by the **National Institute of Standards and Technology (NIST)** in 2001 (FIPS PUB 197). It replaced the older DES standard.

| Parameter | Value |
|-----------|-------|
| Block Size | 128 bits (16 bytes) |
| Key Sizes | 128, 192, or 256 bits |
| Rounds (AES-256) | 14 rounds |
| Structure | Substitution-Permutation Network |
| Security Level (AES-256) | 256-bit (2²⁵⁶ possible keys) |

AES-256 specifically refers to AES with a **256-bit key**, offering the highest level of security among the three AES variants.

---

### 5.2 How OpenSSL Implements AES-256

OpenSSL's **libcrypto** module natively implements AES-256 using optimized routines including:

- **Software implementation** — portable C code
- **Hardware acceleration** — Intel AES-NI instructions (`aes-x86_64.pl`)
- **ARM Cryptography Extensions** — for mobile/embedded platforms

OpenSSL supports AES-256 in multiple **modes of operation**:

| Mode | Full Name | Use Case |
|------|-----------|----------|
| **CBC** | Cipher Block Chaining | File encryption (requires IV) |
| **CFB** | Cipher Feedback | Stream-like encryption |
| **OFB** | Output Feedback | Error-tolerant stream encryption |
| **CTR** | Counter Mode | Parallelizable encryption |
| **GCM** | Galois/Counter Mode | Authenticated encryption (AEAD) |
| **CCM** | Counter with CBC-MAC | Compact authenticated encryption |

---

### 5.3 Key Concepts in OpenSSL AES-256 Usage

#### Initialization Vector (IV)
- A random, non-secret value used to ensure that identical plaintexts produce different ciphertexts.
- In CBC mode, IV must be unpredictable; in CTR/GCM, it must be unique (nonce).
- OpenSSL generates secure IVs using its CSPRNG.

#### Key Derivation from Passwords
When encrypting with a password (rather than a raw key), OpenSSL uses **PBKDF2** (or legacy EVP_BytesToKey) to derive a proper AES-256 key:

```
Password + Salt  →  PBKDF2  →  256-bit AES Key
```

#### Salt
- A random value prepended to derived keys to prevent precomputed dictionary attacks (rainbow tables).
- OpenSSL automatically generates and prepends salt when using password-based encryption.

#### Authentication Tags (GCM Mode)
- AES-256-GCM generates a **128-bit authentication tag** alongside ciphertext.
- This tag verifies both integrity and authenticity of the data.
- Any tampering with the ciphertext causes tag verification to fail.

---

### 5.4 AES-256 in the Context of This Project

AES-256-CBC (or AES-256-GCM) encryption is directly relevant when:

- Encrypting sensitive user data (messages, credentials) stored in a database
- Securing data during migration or transmission between services
- Protecting files or archives from unauthorized access
- Implementing end-to-end encryption in chat or communication applications

OpenSSL provides the underlying cryptographic primitives that higher-level libraries (like Python's `cryptography` package) call internally to perform AES-256 operations.

---

## 6. Practical Commands

The following six commands cover the core operations of OpenSSL — from version checking and random key generation to hashing and AES-256 file encryption/decryption. Each command is documented with its **Purpose**, **Syntax**, **Sample Output**, and **Explanation**.

---

### Command 1 — `openssl version`

#### Purpose
Displays the currently installed version of OpenSSL. This is the first command to run when verifying that OpenSSL is correctly installed on a system. It confirms the library version, which determines what features and algorithms are available.

#### Syntax

```bash
openssl version
```

> **Extended version info** (build date, flags, directories):
> ```bash
> openssl version -a
> ```

#### Sample Output

```
OpenSSL 3.0.2 15 Mar 2022 (Library: OpenSSL 3.0.2 15 Mar 2022)
```

> Extended output with `-a` flag:
> ```
> OpenSSL 3.0.2 15 Mar 2022 (Library: OpenSSL 3.0.2 15 Mar 2022)
> built on: Thu Mar 17 09:17:34 2022 UTC
> platform: linux-x86_64
> options:  bn(64,64)
> compiler: gcc -fPIC -pthread -m64 -Wa,--noexecstack
> OPENSSLDIR: "/usr/lib/ssl"
> ENGINESDIR: "/usr/lib/x86_64-linux-gnu/engines-3"
> MODULESDIR: "/usr/lib/x86_64-linux-gnu/ossl-modules"
> Seeding source: os-specific
> ```

#### Explanation

| Field | Description |
|-------|-------------|
| `OpenSSL 3.0.2` | The version number of the installed OpenSSL library |
| `15 Mar 2022` | The release date of this version |
| `platform: linux-x86_64` | The operating system and CPU architecture |
| `OPENSSLDIR` | Default directory for certificates and configuration files |
| `Seeding source: os-specific` | Entropy source used for random number generation |

- Version **3.x** indicates the modern OpenSSL release with provider-based architecture.
- Older versions (1.0.x, 1.1.x) may lack support for newer algorithms like `ChaCha20-Poly1305` or EdDSA.
- Always ensure the version is **not end-of-life** before deploying in production systems.

---

### Command 2 — `openssl rand -hex 32`

#### Purpose
Generates a **cryptographically secure random number** and outputs it in hexadecimal format. A 32-byte (256-bit) random value is ideal for use as an **AES-256 encryption key** or any other secret requiring high entropy.

#### Syntax

```bash
openssl rand -hex 32
```

> **Syntax breakdown:**
> ```
> openssl rand  -hex  32
>    |            |     |
>    |            |     +-- Number of random BYTES to generate
>    |            +-------- Output format: hexadecimal (2 chars per byte)
>    +-------------------- OpenSSL sub-command: random number generation
> ```

#### Sample Output

```
a3f1c2e9d7b04518c6f2d3a81e9b7045c3f8a21d6e4b0917f5c382a74d6e1b9
```

> **Note:** The output is **different every time** this command is run. It is derived from the OS entropy pool, making it suitable for cryptographic use.
>
> The output is **64 hexadecimal characters** long = 32 bytes × 2 hex characters per byte = 256 bits.

#### Explanation

| Aspect | Detail |
|--------|--------|
| Output Length | 64 hex characters = 32 bytes = 256 bits |
| Randomness Source | OS entropy (`/dev/urandom` on Linux, `BCryptGenRandom` on Windows) |
| Suitable For | AES-256 keys, session tokens, nonces, CSRF tokens |
| Reproducibility | Not reproducible — different output on every call |

- The `-hex` flag converts raw bytes to their hexadecimal string representation.
- Hexadecimal output is safe to use in config files, environment variables, and shell scripts.
- To save the key to a file: `openssl rand -hex 32 > secret.key`
- To generate a Base64-encoded key instead: `openssl rand -base64 32`

---

### Command 3 — `openssl rand -hex 16`

#### Purpose
Generates a **16-byte (128-bit) cryptographically secure random value** in hexadecimal format. This is the standard size for an **Initialization Vector (IV)** used with AES-CBC or AES-CFB encryption modes, and also serves as an AES-128 key.

#### Syntax

```bash
openssl rand -hex 16
```

> **Syntax breakdown:**
> ```
> openssl rand  -hex  16
>    |            |     |
>    |            |     +-- Number of random BYTES to generate (16 = 128 bits)
>    |            +-------- Output format: hexadecimal
>    +-------------------- OpenSSL sub-command: random number generation
> ```

#### Sample Output

```
7f3a9c2d1e4b5f680a9b3c2d7e1f4a5b
```

> **Note:** The output is **32 hexadecimal characters** = 16 bytes = 128 bits.
> This is exactly the AES block size and the standard IV length for all AES modes.

#### Explanation

| Aspect | Detail |
|--------|--------|
| Output Length | 32 hex characters = 16 bytes = 128 bits |
| Primary Use Case | AES Initialization Vector (IV) generation |
| AES Block Size | AES always operates on 128-bit (16-byte) blocks, regardless of key size |
| Uniqueness Requirement | IV must be **unique per encryption operation** (not necessarily secret) |

- In **CBC mode**, the IV ensures that identical plaintexts produce different ciphertexts.
- In **CTR/GCM mode**, this 16-byte value is used as a nonce and must **never be reused** with the same key.
- Difference from Command 2: `rand -hex 32` (256-bit key) vs `rand -hex 16` (128-bit IV).
- Common pattern — generate both key and IV together:
  ```bash
  KEY=$(openssl rand -hex 32)
  IV=$(openssl rand -hex 16)
  echo "Key: $KEY"
  echo "IV:  $IV"
  ```

---

### Command 4 — `echo hello | openssl dgst -sha256`

#### Purpose
Computes the **SHA-256 cryptographic hash** of the string `"hello"` piped through standard input. This demonstrates how OpenSSL can hash arbitrary data in real-time without requiring an input file, and is used to verify data integrity.

#### Syntax

```bash
echo hello | openssl dgst -sha256
```

> **Syntax breakdown:**
> ```
> echo hello  |  openssl  dgst  -sha256
>    |         |     |      |       |
>    |         |     |      |       +-- Hash algorithm: SHA-256
>    |         |     |      +--------- Sub-command: message digest (hashing)
>    |         |     +---------------- OpenSSL toolkit
>    |         +---------------------- Pipe: sends "hello\n" as stdin to openssl
>    +-------------------------------- Outputs the string "hello" to stdout
> ```

#### Sample Output

```
(stdin)= 2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824
```

> **Important note about `echo`:**
> `echo hello` on Linux appends a newline (`\n`), so the hash is actually for `"hello\n"`, not `"hello"`.
> To hash without a trailing newline:
> ```bash
> printf "hello" | openssl dgst -sha256
> # Output: b94d27b9934d3e08a52e52d7da7dabfac484efe04294e576f4e6f0c6a5b4a1e7
> ```

#### Explanation

| Aspect | Detail |
|--------|--------|
| Algorithm | SHA-256 (Secure Hash Algorithm, 256-bit output) |
| Output Length | 64 hexadecimal characters = 32 bytes = 256 bits |
| Input | `"hello\n"` (string with newline from `echo`) |
| Output Label | `(stdin)=` — indicates data was read from standard input |
| Deterministic | Same input **always** produces the same hash |

- SHA-256 is a **one-way function** — the hash cannot be reversed to recover the original data.
- Even a single character change in the input produces a completely different hash (avalanche effect):
  ```
  "hello"  → 2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824
  "Hello"  → 185f8db32921bd46d35b7918c13a04a5a35de53ba7b5b17c5a7e87dfef8c7a3b
  ```
- **Use cases:** File integrity verification, password hashing (with salt), digital signatures, blockchain.
- To hash a file: `openssl dgst -sha256 filename.txt`

---

### Command 5 — `openssl enc -aes-256-cbc -in sample.txt -out sample.enc`

#### Purpose
Encrypts the file `sample.txt` using **AES-256 in CBC (Cipher Block Chaining) mode** and writes the encrypted output to `sample.enc`. This is the core OpenSSL command for symmetric file encryption using the industry-standard AES-256 algorithm.

#### Syntax

```bash
openssl enc -aes-256-cbc -in sample.txt -out sample.enc
```

> **Recommended full syntax** (with salt and PBKDF2 for security):
> ```bash
> openssl enc -aes-256-cbc \
>   -salt \
>   -pbkdf2 \
>   -iter 100000 \
>   -in sample.txt \
>   -out sample.enc
> ```

> **Syntax breakdown:**
> ```
> openssl  enc  -aes-256-cbc  -in sample.txt  -out sample.enc
>    |      |        |              |                |
>    |      |        |              |                +-- Output: encrypted file
>    |      |        |              +----------------- Input: plaintext file
>    |      |        +-------------------------------- Cipher: AES-256-CBC
>    |      +---------------------------------------- Sub-command: symmetric encrypt/decrypt
>    +----------------------------------------------- OpenSSL toolkit
> ```

#### Sample Output

```
Enter encryption password:
Verifying - Enter encryption password:
```

> After entering a password, the encrypted file `sample.enc` is created silently.
> No success message is printed — the absence of an error message indicates success.

> **Hex dump of `sample.enc` (first 32 bytes):**
> ```
> Offset  Hex Bytes                                ASCII
> 00000000  53 61 6c 74 65 64 5f 5f  a1 b2 c3 d4 e5 f6 07 18  Salted__........
> 00000010  8f 3d 2a 1c 9e 4b 7f 05  c2 d1 e0 f9 08 17 26 35  .=*..K........&5
> ```
> - Bytes 0–7: ASCII `"Salted__"` — magic header indicating salted encryption
> - Bytes 8–15: 8-byte random salt
> - Bytes 16+: AES-256-CBC ciphertext

#### Explanation

| Parameter | Description |
|-----------|-------------|
| `enc` | OpenSSL symmetric encryption/decryption sub-command |
| `-aes-256-cbc` | Use AES with 256-bit key in CBC (Cipher Block Chaining) mode |
| `-in sample.txt` | Plaintext input file to be encrypted |
| `-out sample.enc` | Destination file for the encrypted ciphertext |
| `-salt` | Appends random salt to prevent rainbow table attacks |
| `-pbkdf2` | Uses PBKDF2 for password-to-key derivation (more secure than legacy EVP_BytesToKey) |
| `-iter 100000` | PBKDF2 iteration count — increases cost of brute-force attacks |

**How CBC mode works:**
```
Plaintext Block 1  →  XOR with IV          →  AES Encrypt  →  Ciphertext Block 1
Plaintext Block 2  →  XOR with Cipher 1    →  AES Encrypt  →  Ciphertext Block 2
Plaintext Block 3  →  XOR with Cipher 2    →  AES Encrypt  →  Ciphertext Block 3
```
- Each block's encryption depends on the previous ciphertext block.
- If the input file size is not a multiple of 16 bytes, **PKCS#7 padding** is automatically applied.
- The encrypted `.enc` file is **binary** and cannot be viewed as text.

---

### Command 6 — `openssl enc -d -aes-256-cbc -in sample.enc -out sample.txt`

#### Purpose
Decrypts the AES-256-CBC encrypted file `sample.enc` back to its original plaintext content `sample.txt`. This is the reverse operation of Command 5 and requires the **exact same password** that was used during encryption.

#### Syntax

```bash
openssl enc -d -aes-256-cbc -in sample.enc -out sample.txt
```

> **Recommended full syntax** (matching the encryption command):
> ```bash
> openssl enc -d -aes-256-cbc \
>   -pbkdf2 \
>   -iter 100000 \
>   -in sample.enc \
>   -out sample.txt
> ```

> **Syntax breakdown:**
> ```
> openssl  enc  -d  -aes-256-cbc  -in sample.enc  -out sample.txt
>    |      |    |       |              |                |
>    |      |    |       |              |                +-- Output: recovered plaintext
>    |      |    |       |              +----------------- Input: encrypted ciphertext
>    |      |    |       +-------------------------------- Cipher: AES-256-CBC
>    |      |    +---------------------------------------- DECRYPT flag (reverses encryption)
>    |      +-------------------------------------------- Sub-command: symmetric encrypt/decrypt
>    +--------------------------------------------------- OpenSSL toolkit
> ```

#### Sample Output

**On successful decryption:**
```
Enter decryption password:
```
> After entering the correct password, `sample.txt` is created silently with the original content restored.
> No success message is printed — silence indicates success.

**On wrong password:**
```
Enter decryption password:
bad decrypt
80B4B6B2017F0000:error:1C800064:Provider routines:ossl_cipher_unpadblock:bad decrypt:
providers/implementations/ciphers/ciphercommon_block.c:124:
```

**On mismatched PBKDF2 settings:**
```
bad magic number
```
> This occurs when the `-pbkdf2` or `-iter` flags used during decryption do not match those used during encryption.

#### Explanation

| Aspect | Detail |
|--------|--------|
| `-d` flag | Switches `enc` from encryption mode to **decryption mode** |
| Password requirement | Must be **identical** to the password used during encryption |
| PBKDF2 flag | Must match the encryption command — if `-pbkdf2` was used to encrypt, it must be used to decrypt |
| Salt recovery | OpenSSL reads the 8-byte salt from the `"Salted__"` header in `sample.enc` automatically |
| IV recovery | The IV is re-derived from the password + salt using the same KDF |
| Padding removal | PKCS#7 padding added during encryption is automatically stripped |

**Decryption process (CBC mode):**
```
Ciphertext Block 1  →  AES Decrypt  →  XOR with IV          →  Plaintext Block 1
Ciphertext Block 2  →  AES Decrypt  →  XOR with Cipher 1    →  Plaintext Block 2
Ciphertext Block 3  →  AES Decrypt  →  XOR with Cipher 2    →  Plaintext Block 3
```
- Decryption is the exact inverse of encryption — CBC blocks are processed in the same order.
- If even **one byte** of `sample.enc` is corrupted, decryption will produce garbled output or fail entirely.
- Use **AES-256-GCM** instead of CBC if you need decryption to **detect tampering** (authenticated encryption).

---

## 7. Expected Outputs

### 7.1 Summary Table of All Six Commands

| # | Command | Output Type | Output Size |
|---|---------|-------------|-------------|
| 1 | `openssl version` | Version string | 1 line |
| 2 | `openssl rand -hex 32` | 64-char hex string | 256 bits |
| 3 | `openssl rand -hex 16` | 32-char hex string | 128 bits |
| 4 | `echo hello \| openssl dgst -sha256` | 64-char hex hash | 256 bits |
| 5 | `openssl enc -aes-256-cbc -in sample.txt -out sample.enc` | Binary `.enc` file | Varies |
| 6 | `openssl enc -d -aes-256-cbc -in sample.enc -out sample.txt` | Restored `.txt` file | Same as original |

---

### 7.2 Detailed Expected Outputs

**Command 1 — Version:**
```
OpenSSL 3.0.2 15 Mar 2022 (Library: OpenSSL 3.0.2 15 Mar 2022)
```

---

**Command 2 — Random 32-byte key:**
```
a3f1c2e9d7b04518c6f2d3a81e9b7045c3f8a21d6e4b0917f5c382a74d6e1b9
```
*(64 hex characters = 32 bytes = 256 bits. Changes on every run.)*

---

**Command 3 — Random 16-byte IV:**
```
7f3a9c2d1e4b5f680a9b3c2d7e1f4a5b
```
*(32 hex characters = 16 bytes = 128 bits. Changes on every run.)*

---

**Command 4 — SHA-256 of "hello":**
```
(stdin)= 2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824
```
*(Fixed — SHA-256 of `"hello\n"` is always this value.)*

---

**Command 5 — Encrypt sample.txt:**
```
Enter encryption password:         ← User types password (hidden)
Verifying - Enter encryption password:  ← User re-enters to confirm
[No output on success — sample.enc binary file is created]
```

---

**Command 6 — Decrypt sample.enc:**
```
Enter decryption password:         ← User types correct password
[No output on success — sample.txt plaintext file is restored]

--- If wrong password is entered ---
bad decrypt
80B4B6B2017F0000:error:1C800064:Provider routines:ossl_cipher_unpadblock:bad decrypt
```

---

## 8. Conclusion

### Summary

OpenSSL is an indispensable cryptographic tool in both academia and industry. It provides:

- A complete, production-grade implementation of symmetric and asymmetric cryptography
- Full SSL/TLS protocol support for securing network communications
- A rich command-line interface for performing and testing cryptographic operations
- Native, hardware-accelerated support for **AES-256**, one of the strongest and most widely adopted encryption algorithms in existence

### Key Takeaways

| Aspect | Detail |
|--------|--------|
| **Tool Name** | OpenSSL |
| **Type** | Open-source cryptographic library and CLI toolkit |
| **Maintained By** | OpenSSL Software Foundation |
| **Primary Language** | C |
| **Current Stable Version** | OpenSSL 3.x |
| **License** | Apache 2.0 |
| **AES-256 Support** | Full — CBC, GCM, CFB, OFB, CTR modes |
| **FIPS Compliance** | Yes (FIPS 140-2/140-3 module available) |
| **Platform Support** | Linux, Windows, macOS, embedded |

### Relevance to Secure Application Development

For any application dealing with sensitive data — such as a chat application, a database migration tool, or a user authentication system — OpenSSL provides the foundational cryptographic primitives needed to implement:

- **Data-at-rest encryption** using AES-256
- **Data-in-transit security** using TLS 1.2/1.3
- **Password hashing** using PBKDF2 / bcrypt-compatible workflows
- **Digital signatures** for data authenticity verification
- **Certificate management** for PKI-based trust

Mastering OpenSSL is therefore not only an academic exercise but also a practical skill directly applicable to building secure, production-ready software systems.

---

### References

1. OpenSSL Official Documentation — https://www.openssl.org/docs/
2. NIST FIPS PUB 197 — Advanced Encryption Standard (AES), November 2001
3. RFC 8446 — The Transport Layer Security (TLS) Protocol Version 1.3
4. RFC 5280 — Internet X.509 Public Key Infrastructure Certificate
5. NIST Special Publication 800-132 — Recommendation for Password-Based Key Derivation
6. OpenSSL GitHub Repository — https://github.com/openssl/openssl
7. OpenSSL Cookbook (3rd Edition) — Ivan Ristić, Feisty Duck Ltd.

---

*Document prepared for academic study purposes.*
*Topic: OpenSSL Cryptographic Toolkit and AES-256 Encryption*
*Date: June 2026*

---
